/**
 * This package contains main classes for work with CVE data - extended database structure
 */
package extended_mitre.cve;
