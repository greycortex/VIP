/**
 * This package contains classes for work with CAPEC data - extended database structure
 */
package extended_mitre.capec;
