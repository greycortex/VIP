/**
 * This package contains classes related to work with CPE data and their relations - extended database structure
 */
package extended_mitre.cpe;
