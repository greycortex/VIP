/**
 * This package contains classes representing CVSS data structures - extended database structure
 */
package extended_mitre.cvss;
