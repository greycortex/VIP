/**
 * This package contains classes that are used to create and work with extended structure of the database
 */
package extended_mitre;
