/**
 * This package contains classes for work with CWE data - extended database structure
 */
package extended_mitre.cwe;
